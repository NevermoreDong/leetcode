strs = 'helloworld'

strs[0]
strs[1:3]

strs[:5] + 'dodo' # hellododo

x = 1
f'{x+2}'


strs.capitalize()
将字符串的第一个字母变成大写,其他字母变小写。
strs.capitalize() -> Helloworld


strs.center(width, fillchar)
返回一个指定的宽度 width 居中的字符串，fillchar 为填充的字符，默认为空格。
strs.center(30, '*') -> '**********helloworld**********'


strs.count(sub, start, end)
用于统计字符串里某个字符出现的次数。可选参数为在字符串搜索的开始与结束位置
strs.count('o') -> 2


strs.endswith(suffix, start, end)
判断字符串是否以指定后缀结尾,"start" 与 "end" 为检索字符串的开始与结束位置
strs.endswith('ld') -> True


strs.expandtabs(tabsize=8)
把字符串中的tab键转为空格
'ok\tok'.expandtabs() -> 'ok      ok'


strs.find(str, beg=0, end=len(string))
检测 str 是否包含在字符串中，如果指定范围 beg 和 end ，
则检查是否包含在指定范围内，如果包含返回开始的索引值，否则返回-1
strs.find('wor') -> 5


strs.index(str, beg=0, end=len(string))
跟find()方法一样，只不过如果str不在字符串中会报一个异常.
strs.index('h') -> 0


strs.isalnum()
所有字符都是字母或数字则返 回 True,否则返回 False

strs.isalpha()
所有字符都是字母则返回 True, 否则返回 False

strs.isdigit()
字符串只包含数字则返回 True 否则返回 False

strs.islower()
字符都是小写，则返回 True，否则返回 False

strs.isupper()
字符都是大写，则返回 True，否则返回 False


strs.join()
将序列中的元素以指定的字符连接生成一个新的字符串。
s1,s2 = '-',''
sep = ['d', '0', 'd', '0']
s1.join(sep) -> 'd-o-d-o'
s2.joim(sep) -> 'dodo'


len(strs)
返回字符串长度


strs.lower()
将字符串中所有大写字符转换为小写。
strs.swapcase()
将字符串中大写转换为小写，小写转换为大写
strs.upper()
转换字符串中的小写字母为大写


max(strs)
返回字符串 str 中最大的字母。

min(strs)
返回字符串 str 中最小的字母。


strs.replace(old, new, max)
把字符串中的 old 替换成 new，替换不超过 max 次
'do is do is do is'.replace('is', 'was', 2) -> 'do was do was do is'


strs.split(str, num)
通过指定分隔符str，默认空格，对字符串进行切片，分割num次
'ok ok ok'.split() -> ['ok', 'ok', 'ok']
'ok#ok#ok'.split('#', 1) -> ['ok', 'ok#ok']





