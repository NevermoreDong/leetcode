一、冒泡排序：
基本思想：两个数比较大小，较大的数下沉，较小的数冒起来。
def bubble_sort(nums):
	for i in range(0, len(nums)-1):
		for j in range(i+1, len(nums)):
			if nums[i] > nums[j]:
				nums[i], nums[j] = nums[j], nums[i]
	return nums

#include<iostream>
#include<vector>
using namespace std;
& 传入的是地址，在原地址上更改
vector<int> bubble_sort(vector<int>& nums){
    for(int i=0; i<nums.size()-1; i++){
        for(int j=i+1; j<nums.size(); j++){
            if(nums[i] > nums[j]){
                int tmp = nums[j];
                nums[j] = nums[i];
                nums[i] = tmp;
            }
        }
    }
    return nums;
}

int main(){
    vector<int> nums{1,2,5,3,7,4,5,8};
    bubble_sort(nums);
    for(int i=0; i<nums.size(); i++){
        cout << nums[i] << endl;
    }
    return 0;
}



二、选择排序
基本思想：第一次遍历n-1个数，找到最小的数值与第一个元素交换
第二次遍历n-2个数，找到最小的数值与第二个元素交换…………

def selection_sort(nums):
    for i in range(0, len(nums)-1):
        minindex = i
        for j in range(i+1, len(nums)):
            if nums[j] < nums[i]:
                minindex = j
        if minindex != i:
            nums[i], nums[j] = nums[j], nums[i]
    return nums


vector<int> selection_sort(vector<int>& nums){
    for(int i=0; i<nums.size()-1; i++){
        int minindex = i;
        for(int j=i+1; j<nums.size(); j++){
            if(nums[j] < nums[i]){
                minindex = j;
                }
            }
        if(minindex != i){
            int tmp = nums[minindex];
            nums[minindex] = nums[i];
            nums[i] = tmp;
        }
    }
    return nums;
}

三、插入排序
将第i个元素，插入到前面已经拍好的数组中，使其也是有序的。重复

def insert_sort(nums):
    for i in range(1, len(nums)):
        key = nums[i]
        j = i-1
        while j >= 0:
            if key < nums[j]:
                nums[j+1] = nums[j] #这里的j+1位置上的数其实是key的值
                nums[j] = key
            j -= 1
    return nums


vector<int> insert_sort(vector<int>& nums){
    for(int i=1; i<nums.size(); i++){
        int key = nums[i];
        int j = i-1;
        while (j >= 0) {
            if(key < nums[j]){
                nums[j+1] = nums[j];
                nums[j] = key;
            }
            j--;
        }
    }
    return nums;
}

四、快速排序
先从数列中取出一个数作为key值；
将比这个数小的数全部放在它的左边，大于或等于它的数全部放在它的右边。重复

def quick_sort(nums, left, right):
    if left >= right: # 退出递归
        return
    low = left # 提前记录递归的左边界
    high = right # 提前记录递归的右边届
    key = nums[low] # 初始化key值，比key大的放右边，比key小的放左边
    while left < right: # 筛选出本次key值，左边都小，右边都大的数组，跳出时left=right(不懂为啥)
        while left < right and nums[right] > key: # 找到右边比key值小的停下来,因为left位置的值传给key后没用了，先判断右边放到没用的left位置上
            right -= 1
        nums[left] = nums[right] # 把右边错位的值放在array[left]上，看上面left->low->key，所以left这个位置的值已经传给key了，array[left]没用了
        while left < right and nums[left] <= key: # 找到左边比key值大的停下来
            left += 1
        nums[right] = nums[left] # 把左边错位的值放在array[right]上，因为right这个位置上的值已经放到左边了，所以array[right]没用了

    nums[right] = key # 此时left=right，所以传到right或left位置都可以

    quick_sort(nums, low, left - 1) # left或right都可以
    quick_sort(nums, left + 1, high) # left或right都可以

nums = [5,2,9,6,3,7,10,4,1,8,13,54,76,33]
quick_sort(nums,0,len(nums)-1)
print(nums)

void quick_sort(vector<int>& nums, int left, int right){
    if(left >= right){
        return;
    }
    int low = left;
    int high = right;
    int key = nums[low];
    
    while (left < right) {
        while (left < right && nums[right] > key) {
            right--;
        }
        nums[left] = nums[right];
        while (left < right && nums[left] <= key) {
            left++;
        }
        nums[right] = nums[left];
    }
    nums[right] = key;
    quick_sort(nums, low, left-1);
    quick_sort(nums, left+1, high);
}














