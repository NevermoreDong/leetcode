创建：
tup1 = ()
tup1 = (50, ) 

元组中的元素值是不允许修改的，但我们可以对元组进行连接组合

删除：
del tup 

函数：
len(tuple)
max(tuple)
min(tuple)
tuple(iterable)

