函数：

len()
列表元素个数

max()
返回列表元素最大值

min()
返回列表元素最小值

list()
转换为列表

方法：

list.append(obj)
在列表末尾添加新的对象

list.count(obj)
统计某个元素在列表中出现的次数

list.extend(seq)
在列表末尾一次性追加另一个序列中的多个值
l1, l2 = ['1','2'], ['3', '4']
l1.extend(l2) -> ['1','2', '3', '4']

list.index(obj)
从列表中找出某个值第一个匹配项的索引位置

list.insert(index, obj)
将对象插入列表

list.pop(index=-1)
移除列表中的一个元素（默认最后一个元素），并且返回该元素的值

list.remove(obj)
移除列表中某个值的第一个匹配项。

list.reverse()
反向列表中元素

list.clear()
用于清空列表，类似于 del a[:]。

list.copy()
用于复制列表，类似于 a[:]


s1 = [1,2,3,4]
s2 = s1
s3 = s1[:]
s4 = s1.copy()

s1.pop()	
s2 = [1, 2, 3]
s3 = [1,2,3,4]
s4 = [1,2,3,4]

list.sort( key=None, reverse=False)
reverse -- 排序规则，reverse = True 降序， reverse = False 升序（默认）。




