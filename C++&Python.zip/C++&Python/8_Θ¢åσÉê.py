创建一个空集合必须用 set() 而不是 { }，因为 { } 是用来创建一个空字典。
parame = {value01,value02,...}
set(value)


方法：
s.add( x )    	添加元素

s.update( x )	添加元素，且参数可以是列表，元组，字典等

s.remove( x )	移除元素

s.discard( x )	移除集合中的元素，且如果元素不存在，不会发生错误

s.pop()			随机删除集合中的一个元素

s.clear()		清空集合

s.copy()		拷贝一个集合
